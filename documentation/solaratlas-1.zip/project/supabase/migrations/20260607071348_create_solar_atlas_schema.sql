CREATE TABLE IF NOT EXISTS cities (
  id               SERIAL PRIMARY KEY,
  name             TEXT NOT NULL,
  slug             TEXT NOT NULL UNIQUE,
  state            TEXT NOT NULL,
  "stateSlug"      TEXT NOT NULL,
  "stateAbbr"      TEXT NOT NULL,
  lat              DOUBLE PRECISION NOT NULL,
  lng              DOUBLE PRECISION NOT NULL,
  population       INTEGER,

  "annualKwh"      DOUBLE PRECISION,
  "avgSunHours"    DOUBLE PRECISION,
  "solarScore"     INTEGER,
  "monthlyKwh"     TEXT,
  "monthlySunHours" TEXT,

  "avgElectricRate" DOUBLE PRECISION,
  "annualSavings"  DOUBLE PRECISION,
  "paybackYears"   DOUBLE PRECISION,
  "systemCost4kw"  DOUBLE PRECISION,

  "metaTitle"      TEXT,
  "metaDescription" TEXT,

  "createdAt"      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt"      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS states (
  id            SERIAL PRIMARY KEY,
  name          TEXT NOT NULL,
  slug          TEXT NOT NULL UNIQUE,
  abbreviation  TEXT NOT NULL,
  "avgSunHours" DOUBLE PRECISION,
  "avgSavings"  DOUBLE PRECISION,
  "totalCities" INTEGER
);

ALTER TABLE cities ENABLE ROW LEVEL SECURITY;
ALTER TABLE states ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public_read_cities" ON cities FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "service_insert_cities" ON cities FOR INSERT TO service_role WITH CHECK (true);
CREATE POLICY "service_update_cities" ON cities FOR UPDATE TO service_role USING (true) WITH CHECK (true);
CREATE POLICY "service_delete_cities" ON cities FOR DELETE TO service_role USING (true);

CREATE POLICY "public_read_states" ON states FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "service_insert_states" ON states FOR INSERT TO service_role WITH CHECK (true);
CREATE POLICY "service_update_states" ON states FOR UPDATE TO service_role USING (true) WITH CHECK (true);
CREATE POLICY "service_delete_states" ON states FOR DELETE TO service_role USING (true);
