// CRITICAL: Use developer.nlr.gov — the old developer.nrel.gov was RETIRED May 2026

const NLR_BASE = 'https://developer.nlr.gov/api/pvwatts/v8/output.json'

export interface PVWattsResult {
  annualKwh: number
  monthlyKwh: number[]
  solradAnnual: number
  solradMonthly: number[]
  avgSunHours: number
}

export async function fetchPVWattsData(
  lat: number,
  lng: number,
  systemKw: number = 4
): Promise<PVWattsResult | null> {
  try {
    const params = new URLSearchParams({
      api_key: process.env.NLR_API_KEY || 'DEMO_KEY',
      system_capacity: systemKw.toString(),
      lat: lat.toString(),
      lon: lng.toString(),
      azimuth: '180',
      tilt: '20',
      array_type: '1',
      module_type: '0',
      losses: '14',
    })

    const res = await fetch(`${NLR_BASE}?${params}`, {
      next: { revalidate: 86400 },
    })

    if (!res.ok) throw new Error(`API error: ${res.status}`)

    const data = await res.json()

    if (!data.outputs) throw new Error('No outputs in response')

    const solradMonthly: number[] = data.outputs.solrad_monthly || []
    const avgSunHours = solradMonthly.length > 0
      ? Math.round((solradMonthly.reduce((a: number, b: number) => a + b, 0) / 12) * 10) / 10
      : 0

    return {
      annualKwh: Math.round(data.outputs.ac_annual),
      monthlyKwh: data.outputs.ac_monthly.map((v: number) => Math.round(v)),
      solradAnnual: data.outputs.solrad_annual,
      solradMonthly,
      avgSunHours,
    }
  } catch (error) {
    console.error('PVWatts API error:', error)
    return null
  }
}
