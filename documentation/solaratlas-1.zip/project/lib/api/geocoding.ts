export interface GeocodingResult {
  lat: number
  lng: number
  displayName: string
}

export async function geocodeCity(
  city: string,
  state: string
): Promise<GeocodingResult | null> {
  try {
    const query = encodeURIComponent(`${city}, ${state}, USA`)
    const res = await fetch(
      `https://nominatim.openstreetmap.org/search?q=${query}&format=json&limit=1`,
      { headers: { 'User-Agent': 'SolarAtlas/1.0' } }
    )
    const data = await res.json()
    if (!data[0]) return null
    return {
      lat: parseFloat(data[0].lat),
      lng: parseFloat(data[0].lon),
      displayName: data[0].display_name,
    }
  } catch {
    return null
  }
}
