export const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                       'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

export const MONTHLY_FACTORS = [0.06, 0.07, 0.09, 0.10, 0.10, 0.10,
                                  0.10, 0.10, 0.09, 0.08, 0.06, 0.05]

export function calculateAnnualKwh(systemKw: number, sunHours: number): number {
  return Math.round(systemKw * sunHours * 365 * 0.80)
}

export function calculateAnnualSavings(annualKwh: number, ratePerKwh: number): number {
  return Math.round(annualKwh * ratePerKwh)
}

export function calculatePayback(systemCost: number, annualSavings: number): number {
  return Math.round((systemCost / annualSavings) * 10) / 10
}

export function calculateSystemCost(systemKw: number): number {
  return systemKw * 3000
}

export function calculateROI(systemCost: number, annualSavings: number, years: number = 25): number {
  return Math.round((annualSavings * years) - systemCost)
}

export function calculateCO2Offset(annualKwh: number): number {
  return Math.round(annualKwh * 0.386)
}

export function calculateTreesEquivalent(co2Kg: number): number {
  return Math.round(co2Kg / 21)
}

export function generateMonthlyKwh(annualKwh: number): number[] {
  return MONTHLY_FACTORS.map(f => Math.round(annualKwh * f))
}

export function generateMonthlySunHours(avgSunHours: number): number[] {
  return MONTHLY_FACTORS.map(f => Math.round(avgSunHours * f * 30 * 10) / 10)
}
