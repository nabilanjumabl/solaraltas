export function formatKwh(kwh: number): string {
  return `${kwh.toLocaleString()} kWh`
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(amount)
}

export function formatYears(years: number): string {
  return `${years.toFixed(1)} years`
}

export function formatSunHours(hours: number): string {
  return `${hours.toFixed(1)} hrs/day`
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim()
}

export function getSolarScoreLabel(score: number): string {
  if (score >= 90) return 'Excellent'
  if (score >= 75) return 'Very Good'
  if (score >= 60) return 'Good'
  if (score >= 45) return 'Average'
  return 'Below Average'
}

export function getSolarScoreColor(score: number): string {
  if (score >= 90) return '#22C55E'
  if (score >= 75) return '#84CC16'
  if (score >= 60) return '#F59E0B'
  if (score >= 45) return '#F97316'
  return '#EF4444'
}
