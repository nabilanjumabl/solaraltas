import { PrismaClient } from '@prisma/client'
import {
  generateMonthlyKwh,
  generateMonthlySunHours,
  calculateAnnualSavings,
  calculatePayback,
  calculateSystemCost,
} from '../lib/utils/solar'

const prisma = new PrismaClient()

const CITY_DATA: [string, string, string, string, string, number, number, number, number, number, number, number][] = [
  ['Phoenix', 'phoenix', 'Arizona', 'arizona', 'AZ', 33.45, -112.07, 1608139, 7200, 6.5, 98, 0.13],
  ['Tucson', 'tucson', 'Arizona', 'arizona', 'AZ', 32.22, -110.97, 542629, 7100, 6.4, 97, 0.13],
  ['Mesa', 'mesa', 'Arizona', 'arizona', 'AZ', 33.42, -111.83, 504258, 7100, 6.4, 97, 0.13],
  ['Las Vegas', 'las-vegas', 'Nevada', 'nevada', 'NV', 36.17, -115.14, 641903, 6900, 6.3, 96, 0.12],
  ['Honolulu', 'honolulu', 'Hawaii', 'hawaii', 'HI', 21.31, -157.86, 347397, 6800, 6.2, 95, 0.32],
  ['Bakersfield', 'bakersfield', 'California', 'california', 'CA', 35.37, -119.02, 403455, 6500, 6.0, 94, 0.22],
  ['Albuquerque', 'albuquerque', 'New-Mexico', 'new-mexico', 'NM', 35.08, -106.65, 564559, 6500, 6.0, 93, 0.13],
  ['El Paso', 'el-paso', 'Texas', 'texas', 'TX', 31.76, -106.49, 678815, 6400, 5.9, 93, 0.12],
  ['Fresno', 'fresno', 'California', 'california', 'CA', 36.74, -119.77, 530093, 6300, 5.8, 92, 0.22],
  ['Los Angeles', 'los-angeles', 'California', 'california', 'CA', 34.05, -118.24, 3971883, 6200, 5.8, 90, 0.27],
  ['Long Beach', 'long-beach', 'California', 'california', 'CA', 33.77, -118.19, 466742, 6100, 5.7, 89, 0.27],
  ['San Diego', 'san-diego', 'California', 'california', 'CA', 32.72, -117.16, 1386932, 6400, 5.9, 92, 0.27],
  ['Miami', 'miami', 'Florida', 'florida', 'FL', 25.77, -80.19, 470914, 5900, 5.5, 88, 0.13],
  ['Colorado Springs', 'colorado-springs', 'Colorado', 'colorado', 'CO', 38.83, -104.82, 478221, 5900, 5.5, 87, 0.13],
  ['Denver', 'denver', 'Colorado', 'colorado', 'CO', 39.74, -104.98, 715522, 5900, 5.5, 87, 0.13],
  ['Sacramento', 'sacramento', 'California', 'california', 'CA', 38.58, -121.49, 513624, 5900, 5.5, 87, 0.22],
  ['San Jose', 'san-jose', 'California', 'california', 'CA', 37.34, -121.89, 1013240, 5800, 5.4, 86, 0.27],
  ['Austin', 'austin', 'Texas', 'texas', 'TX', 30.27, -97.74, 961855, 5800, 5.4, 86, 0.12],
  ['Jacksonville', 'jacksonville', 'Florida', 'florida', 'FL', 30.33, -81.66, 949611, 5500, 5.2, 82, 0.13],
  ['New Orleans', 'new-orleans', 'Louisiana', 'louisiana', 'LA', 29.95, -90.07, 383997, 5400, 5.1, 81, 0.09],
  ['Houston', 'houston', 'Texas', 'texas', 'TX', 29.76, -95.37, 2304580, 5600, 5.2, 84, 0.11],
  ['San Antonio', 'san-antonio', 'Texas', 'texas', 'TX', 29.42, -98.49, 1434625, 5700, 5.3, 85, 0.11],
  ['Dallas', 'dallas', 'Texas', 'texas', 'TX', 32.78, -96.80, 1343573, 5700, 5.3, 85, 0.12],
  ['Fort Worth', 'fort-worth', 'Texas', 'texas', 'TX', 32.75, -97.33, 935508, 5700, 5.3, 85, 0.12],
  ['Oklahoma City', 'oklahoma-city', 'Oklahoma', 'oklahoma', 'OK', 35.47, -97.52, 681054, 5300, 5.0, 80, 0.10],
  ['Tampa', 'tampa', 'Florida', 'florida', 'FL', 27.95, -82.46, 399700, 5600, 5.3, 83, 0.13],
  ['Orlando', 'orlando', 'Florida', 'florida', 'FL', 28.54, -81.38, 309154, 5700, 5.4, 85, 0.13],
  ['Atlanta', 'atlanta', 'Georgia', 'georgia', 'GA', 33.75, -84.39, 498715, 5200, 4.9, 78, 0.12],
  ['Charlotte', 'charlotte', 'North-Carolina', 'north-carolina', 'NC', 35.23, -80.84, 885708, 5100, 4.8, 77, 0.13],
  ['Raleigh', 'raleigh', 'North-Carolina', 'north-carolina', 'NC', 35.77, -78.64, 467665, 5000, 4.7, 75, 0.12],
  ['Virginia Beach', 'virginia-beach', 'Virginia', 'virginia', 'VA', 36.85, -75.98, 459470, 4800, 4.6, 72, 0.13],
  ['Washington DC', 'washington-dc', 'District-of-Columbia', 'district-of-columbia', 'DC', 38.91, -77.04, 705749, 4600, 4.5, 70, 0.14],
  ['Nashville', 'nashville', 'Tennessee', 'tennessee', 'TN', 36.17, -86.78, 689447, 4900, 4.6, 73, 0.11],
  ['Memphis', 'memphis', 'Tennessee', 'tennessee', 'TN', 35.15, -90.05, 633104, 5000, 4.7, 75, 0.11],
  ['Kansas City', 'kansas-city', 'Missouri', 'missouri', 'MO', 39.10, -94.58, 508090, 4900, 4.6, 73, 0.11],
  ['Omaha', 'omaha', 'Nebraska', 'nebraska', 'NE', 41.26, -95.94, 486051, 5000, 4.7, 75, 0.11],
  ['Indianapolis', 'indianapolis', 'Indiana', 'indiana', 'IN', 39.77, -86.16, 887642, 4600, 4.4, 69, 0.12],
  ['Columbus', 'columbus', 'Ohio', 'ohio', 'OH', 39.96, -82.99, 905748, 4500, 4.3, 67, 0.13],
  ['Louisville', 'louisville', 'Kentucky', 'kentucky', 'KY', 38.25, -85.76, 633045, 4700, 4.5, 71, 0.10],
  ['Baltimore', 'baltimore', 'Maryland', 'maryland', 'MD', 39.29, -76.61, 585708, 4500, 4.4, 68, 0.15],
  ['Philadelphia', 'philadelphia', 'Pennsylvania', 'pennsylvania', 'PA', 39.95, -75.17, 1584064, 4400, 4.3, 66, 0.16],
  ['New York', 'new-york-city', 'New-York', 'new-york', 'NY', 40.71, -74.01, 8336817, 4500, 4.4, 68, 0.23],
  ['Boston', 'boston', 'Massachusetts', 'massachusetts', 'MA', 42.36, -71.06, 695506, 4300, 4.2, 65, 0.25],
  ['Chicago', 'chicago', 'Illinois', 'illinois', 'IL', 41.88, -87.63, 2696555, 4400, 4.3, 66, 0.16],
  ['Detroit', 'detroit', 'Michigan', 'michigan', 'MI', 42.33, -83.05, 670031, 4100, 4.0, 61, 0.18],
  ['Milwaukee', 'milwaukee', 'Wisconsin', 'wisconsin', 'WI', 43.04, -87.91, 577222, 4200, 4.1, 62, 0.17],
  ['Minneapolis', 'minneapolis', 'Minnesota', 'minnesota', 'MN', 44.98, -93.27, 429954, 4500, 4.4, 68, 0.14],
  ['San Francisco', 'san-francisco', 'California', 'california', 'CA', 37.77, -122.42, 873965, 5000, 4.8, 75, 0.28],
  ['Portland', 'portland', 'Oregon', 'oregon', 'OR', 45.52, -122.67, 652503, 4200, 4.0, 62, 0.11],
  ['Seattle', 'seattle', 'Washington', 'washington', 'WA', 47.61, -122.33, 749256, 3800, 3.7, 55, 0.11],
]

async function main() {
  console.log('Seeding SolarAtlas database...')

  for (const row of CITY_DATA) {
    const [name, slug, state, stateSlug, stateAbbr, lat, lng, population,
           annualKwh, avgSunHours, solarScore, avgElectricRate] = row

    const systemCost = calculateSystemCost(4)
    const annualSavings = calculateAnnualSavings(annualKwh, avgElectricRate)
    const paybackYears = calculatePayback(systemCost, annualSavings)
    const monthlyKwh = generateMonthlyKwh(annualKwh)
    const monthlySunHours = generateMonthlySunHours(avgSunHours)

    await prisma.city.upsert({
      where: { slug },
      update: {},
      create: {
        name, slug, state, stateSlug, stateAbbr,
        lat, lng,
        population,
        annualKwh, avgSunHours, solarScore,
        monthlyKwh: JSON.stringify(monthlyKwh),
        monthlySunHours: JSON.stringify(monthlySunHours),
        avgElectricRate,
        annualSavings,
        paybackYears,
        systemCost4kw: systemCost,
        metaTitle: `Solar Potential in ${name}, ${state} | SolarAtlas`,
        metaDescription: `${name} averages ${avgSunHours} peak sun hours/day. A 4kW system produces ${annualKwh.toLocaleString()} kWh/year, saving $${annualSavings.toLocaleString()}/year.`,
      },
    })
    console.log(`  ${name}, ${stateAbbr}`)
  }

  console.log(`\nDone! Seeded ${CITY_DATA.length} cities.`)
}

main().catch(console.error).finally(() => prisma.$disconnect())
